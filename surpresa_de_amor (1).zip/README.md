# Surpresa de Amor

Este é um site estático simples feito em **HTML + CSS + JS**.  
Perfeito para publicar no **GitHub Pages**.

## Como usar

1. Crie um repositório no GitHub.
2. Faça upload do arquivo `index.html` (este aqui).
3. Vá em **Settings > Pages**, escolha a branch `main` e a pasta `/root`.
4. Salve e aguarde alguns minutos.
5. Seu site ficará disponível em `https://teu-usuario.github.io/`.
